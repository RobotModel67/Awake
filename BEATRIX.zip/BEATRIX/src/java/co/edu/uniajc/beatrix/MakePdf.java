/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.uniajc.beatrix;

import co.edu.uniajc.beatrix.entities.Facultad;
import co.edu.uniajc.beatrix.entities.Registro;
import co.edu.uniajc.beatrix.entities.Totales;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.html.simpleparser.HTMLWorker;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author SERVER
 */
@WebServlet(name = "MakePdf", urlPatterns = {"/makePdf"})
public class MakePdf extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    String[] meses = {"Enero", "Febrero", "Marzo",
        "Abril", "Mayo", "Junio", "Julio",
        "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};

    String[] dias = {
        "un (1) dias",
        "dos (2) dias",};

    String nContrato;

    Repository repo;

    @Override
    public void init() throws ServletException {
        repo = new Repository();
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        generarUnContrato(response, Long.parseLong(id));

    }

    protected void generarUnContrato(HttpServletResponse resp, Long id) throws IOException {
        //ByteArrayOutputStream baosPDF = null;
        Registro first = repo.getRegistroById(id);
        List<Registro> registros = repo.getRegistroSameById(id);
        //Long id_facultad = registros.get(0).getId_facultad();
        Facultad facultad = repo.getFacultad(first.getId_facultad());

        ByteArrayOutputStream baosPDF = getDocumentFromHTML(
                registros, first, facultad);

        resp.setHeader("Cache-Control", "max-age=30");
        resp.setContentType("application/pdf");

        String sbFilename = "contrato_"
                + first.getDocumento() + ".pdf";

        resp.setHeader(
                "Content-disposition",
                "inline; filename=" + sbFilename);

        resp.setContentLength(baosPDF.size());
        ServletOutputStream sos;
        sos = resp.getOutputStream();
        baosPDF.writeTo(sos);
        sos.flush();
    }

    protected ByteArrayOutputStream getDocumentFromHTML(List<Registro> registros, Registro first, Facultad facultad) {

        ByteArrayOutputStream baosPDF = new ByteArrayOutputStream();

        Document doc = new Document(PageSize.LETTER);
        doc.addAuthor("Gestión Humana, Universidad Antono José Camacho");
        doc.addCreationDate();
        doc.addProducer();
        doc.addCreator("Dirección de Tecnología y Comunicaciones - UNIACJ");
        doc.addTitle("Contrato Docente.");
        doc.addKeywords("pdf, uniajc, contrato docente");
        //!!! Margenes
        doc.setMargins(71, 66, 140, 88);
        //Header header = new Header("header", "CONTRATO!!");
        //doc.add(header);
        try {
            PdfWriter writer = PdfWriter.getInstance(doc, baosPDF);
            // !!! Header y Footer
            writer.setBoxSize("art", new Rectangle(71, 66, 544, 788));
            ServletContext context = getServletContext();

            try {
                int c = Integer.parseInt(first.getNumero_contrato());
                this.nContrato = String.format("%03d", c);
            } catch (Exception e) {

            }

            HeaderFooter event = new HeaderFooter(
                    context.getRealPath("/WEB-INF/images/uniajc_logo.png"),
                    this.nContrato);

            writer.setPageEvent(event);

            doc.open();

            HTMLWorker hw = new HTMLWorker(doc);

            hw.parse(new StringReader(getDocument(registros, first, facultad)));

        } catch (DocumentException ex) {
            Logger.getLogger(MakePdf.class
                    .getName()).log(Level.SEVERE, null, ex);

        } catch (IOException ex) {
            Logger.getLogger(MakePdf.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        doc.close();
        return baosPDF;
    }

    protected String getDocument(List<Registro> registros, Registro first, Facultad facultad) {
        SimpleDateFormat fmt = new SimpleDateFormat("d 'de' MMMM 'de' yyyy");
        DecimalFormat dfmt = new DecimalFormat("###,###,###,###");

        StringBuilder base = new StringBuilder(readBaseDocument());
        replaceAll(base, "«NOMBRE»", first.getDocente().toUpperCase());

        String sDocumento = first.getDocumento();
        try {
            Integer iDocumento = Integer.parseInt(first.getDocumento());
            sDocumento = dfmt.format(iDocumento);
        } catch (Exception e) {

        }

        replaceAll(base, "«No_CEDULA»", sDocumento);
        replaceAll(base, "«TIPO_DOCUMENTO»", first.getTipo_documento());
        replaceAll(base, "«TIPO_DOCUMENTO_ABREVIADO»", first.getTipo_documento_abreviado());
        
        replaceAll(base, "«CIUDAD_CEDULA»", first.getCiudad_documento());
        replaceAll(base, "«CATEGORIA»", first.getCategoria().toUpperCase());
        replaceAll(base, "«FECHA_INICIO»", fmt.format(first.getFecha_inicio()));
        replaceAll(base, "«FECHA_FINALIZACION»", fmt.format(first.getFecha_final()));

        replaceAll(base, "«Fecha_Firma»", getComplexDate(first.getFecha_inicio()));
        replaceAll(base, "«FACULTAD»", facultad.getFirma());
        replaceAll(base, "«NOMBRE_DECANO»", facultad.getNombreDecano().toUpperCase());
        replaceAll(base, "«CEDULA_DECANO»", dfmt.format(Integer.parseInt(facultad.getDocumentoDecano())));

        replaceAll(base, "«No_CONTRATOS»", this.nContrato);
        replaceAll(base, "«AÑO_FISCAL»", String.format("%d", first.getFecha_inicio().getYear() + 1900));

        if (registros.size() < 8) {
            replaceAll(base, "«ESPACIADO_PRIMERO»", "<tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>");
            replaceAll(base, "«ESPACIADO_MEDIO»", "<tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>");
            replaceAll(base, "«ESPACIADO_ULTIMO»", "<tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>");
        } else {
            replaceAll(base, "«ESPACIADO_PRIMERO»", "<tr><td>&nbsp;</td><td>&nbsp;</td></tr>");
            replaceAll(base, "«ESPACIADO_MEDIO»", "<tr><td>&nbsp;</td><td>&nbsp;</td></tr>");
            replaceAll(base, "«ESPACIADO_ULTIMO»", "<tr><td>&nbsp;</td><td>&nbsp;</td></tr>");
        }
        String flag = "";
                
        HashMap<String, Totales> totalizador = new HashMap<String, Totales>();
        
        /*
        float total_profesional = 0f;
        float total_diplomado = 0f;
        float total_asesorias = 0f;
        float total_centro_idiomas = 0f;
        float total_otras = 0f;

        float valor_profesional = 0f;
        float valor_diplomado = 0f;
        float valor_asesorias = 0f;
        float valor_centro_idiomas = 0f;
        float valor_otras = 0f;
        */
        StringBuilder table = new StringBuilder();
        for (Registro registro : registros) {
            System.out.println(registro.getObservarciones());
            String horas_formato = String.format("%.1f", registro.getHoras_semestre());
            if (registro.getHoras_semestre() % 1 == 0) {
                horas_formato = String.format("%.0f", registro.getHoras_semestre());
            }
            table.append(
                    "<tr><td colspan=\"5\">" + capitalize(registro.getAsignatura()) + "</td>"
                    + "<td align=\"center\">" + registro.getGrupo() + "</td>"
                    + "<td colspan=\"2\" align=\"center\">" + horas_formato + "</td></tr>"
            );
            System.out.println(facultad.getNombre());
            // 2019-05-03 jodida proliferación de tipo_horas
            if (!totalizador.containsKey(registro.getObservarciones())) {
                totalizador.put(registro.getObservarciones(), new Totales());
            }
            Totales total = totalizador.get(registro.getObservarciones());
            total.setHoras(total.getHoras() + registro.getHoras_semestre());
            total.setValor(registro.getValor_hora());
            /*
            if (registro.getObservarciones().equals("PROFESIONAL")) {
                total_profesional += registro.getHoras_semestre();
                valor_profesional = registro.getValor_hora();
            } else if (registro.getObservarciones().equals("DIPLOMADO")) {
                total_diplomado += registro.getHoras_semestre();
                valor_diplomado = registro.getValor_hora();
            } else if (registro.getObservarciones().equals("ASESORIA")) {
                total_asesorias += registro.getHoras_semestre();
                valor_asesorias = registro.getValor_hora();
            } else if (registro.getObservarciones().equals("C.IDIOMAS")) {
                total_centro_idiomas += registro.getHoras_semestre();
                valor_centro_idiomas = registro.getValor_hora();
            } else {
                total_otras += registro.getHoras_semestre();
                valor_otras = registro.getValor_hora();
                flag = registro.getObservarciones();
            }
            */
        }
        //table.append("</table>");

        replaceAll(base,
                "«inserte_aqui_asignaturas»", table.toString());
        // 2017-03-17 Horas paso a ser float 
        //replaceAll(base, "«total_horas»", dfmt.format(total_profesional + total_diplomado + total_asesorias + total_otras));
        float total_horas = 0;
        float total_valores = 0;

        for (Map.Entry<String, Totales> entry : totalizador.entrySet()) {
            //String key = entry.getKey();
            Totales value = entry.getValue();
            total_horas += value.getHoras();
            total_valores += value.getHoras() * value.getValor();
        }
        /*
        if ((total_profesional + total_diplomado + total_asesorias + total_centro_idiomas + total_otras) % 1 == 0) {
            replaceAll(base, "«total_horas»", String.format("%.0f", total_profesional + total_diplomado + total_asesorias + total_centro_idiomas + total_otras));
        } else {
            replaceAll(base, "«total_horas»", String.format("%.1f", total_profesional + total_diplomado + total_asesorias + total_centro_idiomas + total_otras));
        }
        */
        if (total_horas % 1 == 0) {
            replaceAll(base, "«total_horas»", String.format("%.0f", total_horas));
        } else {
            replaceAll(base, "«total_horas»", String.format("%.1f", total_horas));
        }
        /*
        // Celda Horas
        replaceAll(base, "«contrato_horas»", getCeldaHoras(flag, total_profesional, total_diplomado, total_asesorias, total_centro_idiomas, total_otras));

        // valores hora
        replaceAll(base, "«contrato_valores»", getCeldaValores(flag, valor_profesional, valor_diplomado, valor_asesorias, valor_centro_idiomas, valor_otras));
        // celdas totales
        replaceAll(base, "«contrato_totales»", getCeldaTotales(flag,
                total_profesional * valor_profesional,
                total_diplomado * valor_diplomado,
                total_asesorias * valor_asesorias,
                total_centro_idiomas * valor_centro_idiomas,
                total_otras * valor_otras));        
        */
        replaceAll(base, "«contrato_horas»", getCeldaHoras2(totalizador));
        replaceAll(base, "«contrato_valores»", getCeldaValores2(totalizador));
        replaceAll(base, "«contrato_totales»", getCeldaTotales2(totalizador));

        float nCuotas = first.getCuotas();
        //replaceAll(base, "«NUMERO_CUOTAS»", String.format("%.2f", nCuotas));
        replaceAll(base, "«NUMERO_CUOTAS»", String.format("%.2f", nCuotas));
        /*
        int cuota = (int) Math.round(
                (total_profesional * valor_profesional
                + total_diplomado * valor_diplomado
                + total_asesorias * valor_asesorias
                + total_centro_idiomas * valor_centro_idiomas
                + total_otras * valor_otras) / nCuotas);
        */
        int cuota = (int) Math.round(total_valores / nCuotas);
        replaceAll(base, "«VALOR_LETRAS»", NumberToString.Convertir(String.format("%d", cuota), true));
        replaceAll(base, "«VALOR_CUOTA»", dfmt.format(cuota));

        return base.toString();
    }

    protected String readBaseDocument() {
        StringBuilder sb = new StringBuilder();

        String filename = "/WEB-INF/contrato.html";
        ServletContext context = getServletContext();
        InputStream is = context.getResourceAsStream(filename);

        if (is != null) {
            InputStreamReader isr;
            String line;
            try {
                isr = new InputStreamReader(is, "UTF8");
                BufferedReader reader = new BufferedReader(isr);
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                is.close();
            } catch (UnsupportedEncodingException ex) {
                sb.append("UnsupportedEncodingException: " + ex.getMessage());

            } catch (IOException ex) {
                sb.append("IOException: " + ex.getMessage());
            }

        }
        return sb.toString();
    }

    public static void replaceAll(StringBuilder builder, String from, String to) {
        int index = builder.indexOf(from);
        while (index != -1) {
            builder.replace(index, index + from.length(), to);
            index += to.length(); // Move to the end of the replacement
            index = builder.indexOf(from, index);
        }
    }

    private String getComplexDate(Date date) {
        StringBuilder sb = new StringBuilder();
        int day = date.getDate();
        if (day == 1) {
            sb.append("a los un (1) días");
        } else {
            sb.append(
                    String.format(
                            "a los %s (%d) días",
                            NumberToString.Convertir(String.format("%d", day), false),
                            day));
        }
        sb.append(
                String.format(
                        " del mes de %s de %d",
                        meses[date.getMonth()],
                        date.getYear() + 1900));
        return sb.toString();
    }

    private String capitalize(String input) {
        return input.toUpperCase();
        //return input.substring(0, 1).toUpperCase() + input.substring(1).toLowerCase();
    }

    private String getCeldaHoras(String flag, float profesional, float diplomado, float asesoria, float centro_idiomas, float otras) {
        int items = 0;
        StringBuilder sb = new StringBuilder();

        if (profesional > 0) {
            if (profesional % 1 == 0) {
                sb.append(String.format("PROFESIONAL: %.0f<br>", profesional));
            } else {
                sb.append(String.format("PROFESIONAL: %.1f<br>", profesional));
            }
            items++;
        }
        if (diplomado > 0) {
            if (profesional % 1 == 0) {
                sb.append(String.format("DIPLOMADO: %.0f<br>", diplomado));
            } else {
                sb.append(String.format("DIPLOMADO: %.1f<br>", diplomado));
            }
            items++;
        }
        if (asesoria > 0) {
            if (profesional % 1 == 0) {
                sb.append(String.format("ASESORIA: %.0f<br>", asesoria));
            } else {
                sb.append(String.format("ASESORIA: %.1f<br>", asesoria));
            }
            items++;
        }
        if (centro_idiomas > 0) {
            if (centro_idiomas % 1 == 0) {
                sb.append(String.format("C.IDIOMAS: %.0f<br>", centro_idiomas));
            } else {
                sb.append(String.format("C.IDIOMAS: %.1f<br>", centro_idiomas));
            }
            items++;
        }
        if (otras > 0) {
            if (profesional % 1 == 0) {
                sb.append(String.format("%s: %.0f<br>", flag, otras));
            } else {
                sb.append(String.format("%s: %.1f<br>", flag, otras));
            }
            //sb.append(String.format("%s: %.1f<br>", flag, otras));
            items++;
        }

        if (items > 1) {
            if (profesional % 1 == 0) {
                sb.append(String.format("TOTAL HORAS: %.0f", profesional + diplomado + asesoria + centro_idiomas + otras));
            } else {
                sb.append(String.format("TOTAL HORAS: %.1f", profesional + diplomado + asesoria + centro_idiomas + otras));
            }

            //sb.append(String.format("TOTAL HORAS: %.1f", profesional + diplomado + asesoria + otras));
        }

        return sb.toString();
    }

    private String getCeldaValores(String flag, float profesional, float diplomado, float asesoria, float centro_idiomas, float otros) {
        DecimalFormat dfmt = new DecimalFormat("###,###,###,###");
        StringBuilder sb = new StringBuilder();
        if (profesional > 0) {
            sb.append(String.format("PROFESIONAL: $%s<br>", dfmt.format(profesional)));
        }
        if (diplomado > 0) {
            sb.append(String.format("DIPLOMADO: $%s<br>", dfmt.format(diplomado)));
        }
        if (asesoria > 0) {
            sb.append(String.format("ASESORIA: $%s<br>", dfmt.format(asesoria)));
        }
        if (centro_idiomas > 0) {
            sb.append(String.format("C.IDIOMAS: $%s<br>", dfmt.format(centro_idiomas)));
        }
        if (otros > 0) {
            sb.append(String.format("%s: $%s<br>", flag, dfmt.format(otros)));
        }
        return sb.toString();
    }

    private String getCeldaTotales(String flag, float profesional, float diplomado, float asesoria, float centro_idiomas, float otros) {
        DecimalFormat dfmt = new DecimalFormat("###,###,###,###");
        StringBuilder sb = new StringBuilder();

        int items = 0;
        if (profesional > 0) {
            items++;
        }
        if (diplomado > 0) {
            items++;
        }
        if (asesoria > 0) {
            items++;
        }
        if (centro_idiomas > 0) {
            items++;
        }
        if (otros > 0) {
            items++;
        }
        if (items == 1) {
            if (profesional > 0) {
                sb.append(String.format("TOTAL $%s<br>", dfmt.format(profesional)));
            }
            if (diplomado > 0) {
                sb.append(String.format("TOTAL $%s<br>", dfmt.format(diplomado)));
            }
            if (asesoria > 0) {
                sb.append(String.format("TOTAL $%s<br>", dfmt.format(asesoria)));
            }
            if (centro_idiomas > 0) {
                sb.append(String.format("TOTAL $%s<br>", dfmt.format(centro_idiomas)));
            }
            if (otros > 0) {
                //sb.append(String.format("TOTAL %s $%s<br>", flag, dfmt.format(otros)));
                sb.append(String.format("TOTAL $%s<br>", dfmt.format(otros)));
            }
        } else {
            if (profesional > 0) {
                sb.append(String.format("$%s<br>", dfmt.format(profesional)));
            }
            if (diplomado > 0) {
                sb.append(String.format("$%s<br>", dfmt.format(diplomado)));
            }
            if (asesoria > 0) {
                sb.append(String.format("$%s<br>", dfmt.format(asesoria)));
            }
            if (centro_idiomas > 0) {
                sb.append(String.format("$%s<br>", dfmt.format(centro_idiomas)));
            }
            if (otros > 0) {
                //sb.append(String.format("%s $%s<br>", flag, dfmt.format(otros)));                
                sb.append(String.format("$%s<br>", dfmt.format(otros)));
            }
            sb.append(String.format("TOTAL: $%s", dfmt.format(profesional + diplomado + asesoria + centro_idiomas + otros)));
        }

        return sb.toString();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String getCeldaHoras2(HashMap<String, Totales> totalizador) {
        int items = 0;
        float sumatoria = 0;
        DecimalFormat dfmt = new DecimalFormat("###,###,###,###");
        StringBuilder sb = new StringBuilder();

        for (Map.Entry<String, Totales> entry : totalizador.entrySet()) {
            String key = entry.getKey();
            Totales value = entry.getValue();
            sb.append(String.format("%s: %s<br>", key, dfmt.format(value.getHoras())));
            items++;
            sumatoria += value.getHoras();
        }

        if (items > 1) {
            if (sumatoria % 1 == 0) {
                sb.append(String.format("TOTAL HORAS: %.0f", sumatoria));
            } else {
                sb.append(String.format("TOTAL HORAS: %.1f", sumatoria));
            }
        }

        return sb.toString();
    }

    private String getCeldaValores2(HashMap<String, Totales> totalizador) {
        DecimalFormat dfmt = new DecimalFormat("###,###,###,###");
        StringBuilder sb = new StringBuilder();
        
        for (Map.Entry<String, Totales> entry : totalizador.entrySet()) {
            String key = entry.getKey();
            Totales value = entry.getValue();
            sb.append(String.format("%s: $%s<br>", key, dfmt.format(value.getValor())));
        }
        return sb.toString();
    }

    private String getCeldaTotales2(HashMap<String, Totales> totalizador) {
        DecimalFormat dfmt = new DecimalFormat("###,###,###,###");
        StringBuilder sb = new StringBuilder();
        float sumatoria = 0;
        for (Map.Entry<String, Totales> entry : totalizador.entrySet()) {
            String key = entry.getKey();
            Totales value = entry.getValue();
            sumatoria += value.getHoras() * value.getValor();
            if (totalizador.size() > 1) {
                sb.append(String.format("$%s<br>", dfmt.format(value.getHoras() * value.getValor())));
            }
        }
        sb.append(String.format("TOTAL: $%s", dfmt.format(sumatoria)));
        return sb.toString();
    }

}
