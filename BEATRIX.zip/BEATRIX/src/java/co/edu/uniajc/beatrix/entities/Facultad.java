/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.uniajc.beatrix.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author jlvalencia
 */
@Entity()
@Table(name = "facultad")
public class Facultad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "facultad_id")
    Long id;

    @Column(name = "facultad")
    String nombre;

    @Column(name = "nombre_decano")
    String nombreDecano;

    @Column(name = "documento_decano")
    String documentoDecano;

    @Column(name = "firma")
    String firma;
    
    public Facultad() {
    }

    public Facultad(String nombre) {
        this.nombre = nombre;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombreDecano() {
        return nombreDecano;
    }

    public void setNombreDecano(String nombreDecano) {
        this.nombreDecano = nombreDecano;
    }

    public String getDocumentoDecano() {
        return documentoDecano;
    }

    public void setDocumentoDecano(String documentoDecano) {
        this.documentoDecano = documentoDecano;
    }

    public String getFirma() {
        return firma;
    }

    public void setFirma(String firma) {
        this.firma = firma;
    }

    @Override
    public String toString() {
        return String.format("{id: %d, facultad: %s, decano: %s, documento: %s}",
                id, nombre, nombreDecano, documentoDecano);
    }
}
