/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.uniajc.beatrix;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.IOException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jlvalencia
 */
public class HeaderFooter extends PdfPageEventHelper {

    Phrase[] header = new Phrase[2];
    int pagenumber;
    Image logo;
    Chunk chunk;
    String contrato;
    Font f;
    
    public HeaderFooter(String logoSource, String contrato) {
        
        f = FontFactory.getFont("Arial", 10f);
        try {
            logo = Image.getInstance(logoSource);
            logo.setAlignment(Image.MIDDLE);
            logo.scaleAbsoluteHeight(20);
            logo.scaleAbsoluteWidth(20);
            logo.scalePercent(100);
            chunk = new Chunk(logo, 0, -45);

            /*
            try {
                int c = Integer.parseInt(contrato);
                contrato = String.format("%03d", c);
            } catch (Exception e) {
                contrato = "___";
            }
            */
            
            this.contrato = contrato;
        } catch (BadElementException ex) {
            Logger.getLogger(HeaderFooter.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("MAL: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("MAL: " + ex.getMessage());

        }
    }

    public void onOpenDocument(PdfWriter writer, Document document) {
        header[0] = new Phrase("CONTRATO DOCENCIA HORA CÁTEDRA No. " + this.contrato + " POR LA", f);
        header[1] = new Phrase("DURACIÓN DEL PERIODO ACADÉMICO EXPRESAMENTE DETERMINADO", f);
    }

    public void onStartPage(PdfWriter writer, Document document) {
        pagenumber++;
        ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER, new Phrase("Top Left"), 30, 800, 0);
        ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER, new Phrase("Top Right"), 550, 800, 0);
    }

    public void onEndPage(PdfWriter writer, Document document) {
        Rectangle rect = writer.getBoxSize("art");
        ColumnText.showTextAligned(writer.getDirectContent(),
                Element.ALIGN_LEFT, new Phrase(chunk),
                rect.getLeft(), rect.getTop()-20, 0);
        
        ColumnText.showTextAligned(writer.getDirectContent(),
                Element.ALIGN_CENTER, header[0],
                (rect.getLeft() + rect.getRight(    )) / 2, rect.getTop() - 92, 0);

        ColumnText.showTextAligned(writer.getDirectContent(),
                Element.ALIGN_CENTER, header[1],
                (rect.getLeft() + rect.getRight()) / 2, rect.getTop() - 110, 0);

        ColumnText.showTextAligned(writer.getDirectContent(),
                Element.ALIGN_LEFT, new Phrase(
                        "UNIAJC / 805000889-0", f),
                rect.getLeft(),
                rect.getBottom() - 18, 0);
        ColumnText.showTextAligned(writer.getDirectContent(),
                Element.ALIGN_RIGHT, new Phrase(
                        String.format("%d", pagenumber), f),
                rect.getRight(),
                rect.getBottom() - 18, 0);

    }
}
