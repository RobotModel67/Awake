package jollyJerbo.api.persistence;

public class Repository {
	
}
