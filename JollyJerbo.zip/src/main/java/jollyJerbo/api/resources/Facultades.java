package jollyJerbo.api.resources;

import java.util.List;

//import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import jollyJerbo.api.domain.Facultad;

@Path("facultades")
public class Facultades {

	//@Inject
	private EntityManager database;
	
	public Facultades() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("alice");
		database = emf.createEntityManager();
		
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response test() {
		//return Response.ok("IA Love You, not leave me now!").build();
		List<Facultad> facultades = database.createQuery("SELECT f FROM Facultad f", Facultad.class).getResultList();
		return Response.ok(facultades).build();
	}
	
}
